﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HelperLibrary.Validator
{
    public class IArgumentValidator
    {
    }
    public class ArgumentValidator
    {
    }
}
