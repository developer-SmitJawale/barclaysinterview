﻿using System;
using ThirdPartyTools;

// Note this library developed using MEF

namespace HelperLibrary
{
    public interface IFileHelper
    {
        bool ProcessArguments(string[] args);
    }

    public class FileHelper : IFileHelper
    {
        public FileDetails FileDetails { get; set; }

        public FileHelper()
        {
            FileDetails = new FileDetails();
        }
        public bool ProcessArguments(string[] args)
        {
            if (args.Length == 0)
                return false;

            if (args[0] == "-v")
                Console.WriteLine( FileDetails.Version(args[1]));

            return false;
        }
    }
}
