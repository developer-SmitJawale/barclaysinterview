﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestFileHelper.Moc
{
    public class MocDetails
    {
        public string Version(string filePath)
        {
            return "test version";
        }

        public int Size(string filePath)
        {
            return 100;
        }
    }
}
