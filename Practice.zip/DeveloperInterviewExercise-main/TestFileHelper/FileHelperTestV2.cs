﻿using NUnit.Framework;

namespace TestFileHelper
{
    public class FileHelperTestV2
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ValidateParameter()
        {
        }
    }
}