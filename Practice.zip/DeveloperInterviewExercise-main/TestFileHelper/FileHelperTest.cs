using FileHelperV2;
using NUnit.Framework;
using TestFileHelper.Moc;

namespace TestFileHelper
{
    public class FileHelperTestV1
    {
        [SetUp]
        public void Setup()
        {

        }

        [Test]
        public void ValidateParameterPositiveTests()
        {
            // Arrange
            var args = new string[] { "-v", "1" };
            var helper = new FileHelper();

            // Act
            var result = helper.ProcessArguments(args);

            // Assert
            Assert.IsTrue(result);
        }

        [Test]
        public void ValidateParameterNegativeTests()
        {
            // Arrange
            var args = new string[] { "-vv", "1" };
            var helper = new FileHelper();

            // Act
            var result = helper.ProcessArguments(args);

            // Assert
            Assert.IsTrue(result);
        }
    }
}