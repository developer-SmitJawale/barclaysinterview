﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ThirdPartyTools;

namespace FileHelperV2
{
    public interface IFileHelper
    {
        bool ProcessArguments(string[] args);
    }

    public class FileHelper : IFileHelper
    {
        public FileDetails FileDetails { get; set; }

        public FileHelper()
        {
            FileDetails = new FileDetails();
        }
        public bool ProcessArguments(string[] args)
        {
            bool result = false;

            if (args.Length == 0)
                return result;

            if (args[0] == "-v" || args[0] == "--v" || args[0] == "/v" || args[0] == "--version")
            {
                Console.WriteLine(FileDetails.Version(args[1]));
                result = true;
            }

            if (args[0] == "-s" || args[0] == "--s" || args[0] == "/s" || args[0] == "--size")
            {
                Console.WriteLine(FileDetails.Version(args[1]));
                result = true;
            }

            return result;
        }
    }
}
